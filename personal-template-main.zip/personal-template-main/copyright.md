seluruh hak cipta dimiliki oleh Spencer Sharp from tailwinds, dan di rebuild tampilannya oleh M Alfito Rahman.
